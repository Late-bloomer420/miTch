# Architecture Core (Concept)

## Actors
- **User Device (Wallet / miTch Client):** Root of trust; erstellt Proofs; evaluiert Policies lokal.
- **Issuer/State Provider:** hält authoritative PII; stellt Credentials aus (oder mdoc/SD-JWT etc).
- **Requester / Relying Party (RP):** fordert minimale Claims/Proofs an; verifiziert; bekommt keine Roh-PII.
- **Policy Authority (optional):** publiziert Policy-Manifeste / Predicate-Kataloge (ohne User-Daten).

## Core Building Blocks
- **Policy Manifest:** maschinenlesbare Regeln + minimale Datenanforderungen.
- **Request Binding:** Kryptografische Bindung von Request/Response an RP + Session (AAD/Context binding).
- **Selective Disclosure / ZK Proof Layer:** Ergebnis-orientierte Nachweise (“true/false” + Evidenz).
- **Audit Trail (WORM):** Ereignisse verifizierbar, aber PII-minimal & pseudonym.

## Trust Boundaries
- PII bleibt beim Issuer/State bzw. im User-Device (transaktional).
- RP bekommt nur Proofs + minimal notwendige Metadaten.
