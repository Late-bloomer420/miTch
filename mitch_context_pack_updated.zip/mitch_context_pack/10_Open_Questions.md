# Open Questions (Concept)

1. Welche Credential-Formate priorisieren wir (SD-JWT, mdoc, BBS+) — und warum?
2. Wie minimieren wir Metadaten in RP↔User Interaktionen (routing, timing, batching)?
3. Recovery: Social recovery vs. hardware-bound vs. issuer-assisted — mit minimaler Linkability.
4. Audit: Welche Events sind “must log”, ohne PII/Profiling zu erzeugen?
5. Compliance mapping: eIDAS2/EUDI Wallet alignment — welche Abhängigkeiten sind akzeptabel?
