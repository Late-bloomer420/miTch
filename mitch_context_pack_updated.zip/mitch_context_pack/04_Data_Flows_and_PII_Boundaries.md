# Data Flows & PII Boundaries

## Ziel
PII darf **nicht** zum Requester leaken — weder direkt (Payload) noch indirekt (Metadaten).

## Primary Boundary
- **Issuer/State DB**: authoritative PII (Passport, Registry etc.)
- **User Device**: hält Credential / Key material; produziert Proofs
- **Requester**: bekommt nur Proofs / Results

## Metadata Leak Vectors (müssen aktiv mitigiert werden)
- Stable identifiers (device IDs, correlation handles)
- Linkability across RPs
- Timing / size patterns
- Logging (server-side) mit zu vielen Details

## Mechanische Controls (Konzept)
- Pseudonyme per-RP (pairwise identifiers) oder komplett identifierless
- Bounded, TTL-based stores (nonce/rate-limit) → keine Langzeitprofile
- Minimal logs (event types, counts, coarse timestamps)
- Deterministic policy evaluation + deny by default
