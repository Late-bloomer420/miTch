# miTch Context Pack

Stand: 2026-02-11 (Concept Phase / T0)

Dieses Paket ist dafür gedacht, in neue Chats/Tools als Projekt-Kontext kopiert zu werden.

## Quick Start
- Lies zuerst **01_Project_OnePager.md**
- Dann **02_Principles_and_NonNegotiables.md**
- Dann **04_Data_Flows_and_PII_Boundaries.md**
- Für Roadmap: **07_Backlog_and_Implemented_Tasks.md**

## Naming
- Projektname: **miTch**
- Arbeitsname für den Security/Hardening-Stack: **miTch Shield** (optional / noch nicht final)

## Core Invariant
miTch funktioniert nicht, weil es alles weiß, sondern weil es strukturell nicht wissen *kann*, was es nicht wissen darf.
