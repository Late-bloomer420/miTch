# Glossary (mini)

- **PII**: Personally Identifiable Information
- **RP**: Relying Party (Requester)
- **Issuer**: Authoritative issuer (z. B. State/Registry)
- **Selective Disclosure**: nur Teilinformationen offenlegen
- **ZK Proof**: Nachweis ohne Preisgabe der Rohdaten
- **AAD / Context Binding**: Kryptografische Bindung an Kontext/Empfänger
- **Fail-closed**: bei Unsicherheit verweigern
- **WORM**: Write Once Read Many (append-only audit)
