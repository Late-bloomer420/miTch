# Threat Model (Concept Snapshot)

## Adversaries
- Malicious RP (wants to learn more than allowed)
- Network observer (metadata correlation)
- Compromised device (malware)
- Compromised issuer endpoint
- Replay / injection attackers

## Primary Goals
- Prevent PII disclosure to RP
- Prevent linkability across contexts
- Ensure integrity of policy evaluation & proof binding
- Fail-closed under uncertainty

## High-risk Areas
- Metadata correlation (harder than payload encryption)
- Key theft / recovery abuse
- Weak request/response binding (replay)
- Unbounded stores → implicit profiling
