# Policy Engine Spec (Concept)

## Design
- Inputs: Policy Manifest + Request Context + Local Evidence/Claims
- Output: ALLOW/DENY + minimal proof artifacts

## Semantics
- Deterministic evaluation
- Fail-closed on missing paths / schema mismatch
- Explicit precedence rules (e.g., hard-deny gates first)

## Policy Manifest (minimal)
- version, issuer(s), predicates, required proofs, binding requirements
- privacy budget / minimization constraints
