# Principles & Non-Negotiables

## Binding Principles
1. **Edge-First Decisions**
2. **Ephemerality by Default**
3. **Data Minimization by Construction**
4. **User as Root of Trust**
5. **Fail-Closed Logic**

## Automatic Rejections (Designs, die wir nicht bauen)
- Zentrale Identity-Storage / zentrale User-Profile
- Behavioral Analytics / Profiling
- Blockchain-Abhängigkeit für Core-Identity
- Custody von Assets/Tokens/NFTs
- “Trust us”-Modelle statt erzwingbarer Guarantees

## Safety / Honesty Rules
- Keine “TEE solves everything”-Behauptungen ohne messbare, verifizierbare Garantien.
- Keine Server-Annahme über Zugriff auf User-Secrets.
- Keine Zweckentfremdung von Daten über den expliziten Zweck hinaus.
