# miTch — One-Pager (Concept Phase)

## Ziel
miTch ist eine **user-sovereign Identity- & Authorization-Architektur** (EU-first), die **verifizierbares Vertrauen ohne zentrale Datencustody** ermöglicht.

## Kernversprechen (mechanisch erzwungen, nicht “trust us”)
- **Edge-first decisions:** Identitäts-/Autz-Entscheidungen passieren lokal auf dem User-Device.
- **Data minimization by construction:** Der Requester erhält nur das Minimum (z. B. “>=18: true”), nicht die zugrundeliegenden Daten.
- **Ephemerality by default:** Transaktionale Daten, Löschung/Key-Destruction = Erasure.
- **Fail-closed:** Unklarheit/Policy mismatch/Unsicherheit → **DENY**.
- **Audit-verifiable without PII:** Prüfpfade sind überprüfbar, ohne PII offenzulegen.

## Problem Space
Regulierte Services brauchen verlässliche Attribute (Age, Residency, Eligibility), aber heutige Flows leaken PII & Metadaten (Profiling, Identifier-Sprawl).

## High-level Approach
- **State/Issuer-provided PII bleibt beim Issuer/State** (Datenhoheit bleibt dort).
- User hält **Wallet/Credentials** und erzeugt **selektive Nachweise** (Selective Disclosure / ZK).
- Requester verifiziert nur **Proofs + Policy** (keine Rohdaten).

## Out of scope / Non-goals
Siehe **99_WHAT_MITCH_IS_NOT.md**.
